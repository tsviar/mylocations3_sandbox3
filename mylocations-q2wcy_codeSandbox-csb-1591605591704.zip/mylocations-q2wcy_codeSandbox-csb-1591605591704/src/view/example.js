import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useHistory,
  useLocation,
  useParams
} from "react-router-dom";

// This example shows how to render two different screens
// (or the same screen in a different context) at the same URL,
// depending on how you got there.
//
// Click the "featured images" and see them full screen. Then
// "visit the gallery" and click on the colors. Note the URL and
// the component are the same as before but now we see them
// inside a modal on top of the gallery screen.

export default function ModalGalleryExample() {
  return (
    <Router>
      <ModalSwitch />
    </Router>
  );
}

function ModalSwitch() {
  let location = useLocation();

  // This piece of state is set when one of the
  // gallery links is clicked. The `background` state
  // is the location that we were at when one of
  // the gallery links was clicked. If it's there,
  // use it as the location for the <Switch> so
  // we show the gallery in the background, behind
  // the modal.
  let background = location.state && location.state.background;

  return (
    <div>
      <Switch location={background || location}>
        <Route exact path="/" children={<Home />} />
        <Route path="/gallery" children={<Gallery />} />
        <Route path="/img/:id" children={<ImageView />} />
      </Switch>

      {/* Show the modal when a background page is set */}
      {background && <Route path="/img/:id" children={<Modal />} />}
    </div>
  );
}

const IMAGES = [
  { id: 0, title: "Dark Orchid", color: "DarkOrchid" },
  { id: 1, title: "Lime Green", color: "LimeGreen" },
  { id: 2, title: "Tomato", color: "Tomato" },
  { id: 3, title: "Seven Ate Nine", color: "#789" },
  { id: 4, title: "Crimson", color: "Crimson" }
];

function Thumbnail({ color }) {
  return (
    <div
      style={{
        width: 50,
        height: 50,
        background: color
      }}
    />
  );
}

function Image({ color }) {
  return (
    <div
      style={{
        width: "100%",
        height: 400,
        background: color
      }}
    />
  );
}

function Home() {
  return (
    <div>
      <Link to="/gallery">Visit the Gallery</Link>
      <h2>Featured Images</h2>
      <ul>
        <li>
          <Link to="/img/2">Tomato</Link>
        </li>
        <li>
          <Link to="/img/4">Crimson</Link>
        </li>
      </ul>
    </div>
  );
}

function Gallery() {
  let location = useLocation();

  return (
    <div>
      {IMAGES.map(i => (
        <Link
          key={i.id}
          to={{
            pathname: `/img/${i.id}`,
            // This is the trick! This link sets
            // the `background` in location state.
            state: { background: location }
          }}
        >
          <Thumbnail color={i.color} />
          <p>{i.title}</p>
        </Link>
      ))}
    </div>
  );
}

function ImageView() {
  let { id } = useParams();
  let image = IMAGES[parseInt(id, 10)];

  if (!image) return <div>Image not found</div>;

  return (
    <div>
      <h1>{image.title}</h1>
      <Image color={image.color} />
    </div>
  );
}

function Modal() {
  let history = useHistory();
  let { id } = useParams();
  let image = IMAGES[parseInt(id, 10)];

  if (!image) return null;

  let back = e => {
    e.stopPropagation();
    history.goBack();
  };

  return (
    <div
      onClick={back}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        background: "rgba(0, 0, 0, 0.15)"
      }}
    >
      <div
        className="modal"
        style={{
          position: "absolute",
          background: "#fff",
          top: 25,
          left: "10%",
          right: "10%",
          padding: 15,
          border: "2px solid #444"
        }}
      >
        <h1>{image.title}</h1>
        <Image color={image.color} />
        <button type="button" onClick={back}>
          Close
        </button>
      </div>
    </div>
  );
}



///=======================================================================
////   FTP insert unsorted data packet to its right place
////=====================================================================

// Basic function: insert one new number
//===================================================

const InsertSortInputData = (newArrival, InSortedA) => {
  //console.log('insertSortInputData START)', newArrival,  InSortedA );

  let SArr = [];

  if (InSortedA.length === 0) {
    SArr.push(newArrival);

    //console.log('InSortedA.length === 0 SArr ' , SArr);

    return SArr;
  } else {
    SArr = InSortedA.concat();
    //console.log('copy InArr  SArr ' , InSortedA, SArr);
  }

  //console.log('insertSortInputData 2 newArrival InSortedA SArr',
  //                                 newArrival, InSortedA, SArr );

  // find first index of a bigger then val

  if (InSortedA[InSortedA.length - 1] <= newArrival) {
    SArr.push(newArrival);
    // console.log('push at END InSortedA SArr ' , InSortedA, SArr);

    return SArr;
  }

  // -4 -3 -2 -1 0 1 2 3 4

  var foundBigger = SArr.find(sa => sa >= newArrival);
  //console.log('insertSortInputData foundBigger)',  foundBigger );

  var foundBiggerIdx = SArr.indexOf(foundBigger);
  //console.log('insertSortInputData foundBiggerIdx)',  foundBiggerIdx );

  const INSERT_ONLY = 0;
  SArr.splice(foundBiggerIdx, INSERT_ONLY, newArrival);

  //console.log('insertSortInputData END)', newArrival,  SArr );

  return SArr;
};

const SA = [-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5];
//const SA = [];
//  0   1  2  3  4  5  6  7   8  9  10
//const newVal = 9;
//const newVal = 2;
//const newVal = 5;
const newVal = 3;

console.log("calling insertSortInputData)", newVal, SA);

var t0 = performance.now();

var SAOut = InsertSortInputData(newVal, SA); // <---- The function you're measuring time for

var t1 = performance.now();

console.log("result SAOut", SAOut);
console.log("Call to InsertSortInputData took " + (t1 - t0) + " milliseconds.");

/*
// Tests results
3
[-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5]
[-4, -1, 0, 0, 3, 3, 3, 3, 4, 4, 5, 5]
5
[-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5]
[-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5, 5]

2
[-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5]
[-4, -1, 0, 0, 2, 3, 3, 3, 4, 4, 5, 5]

-9
[-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5]
[-9, -4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5]

-9
[]
[-9]
*/


// Usage function: insert an unsorted set of numbers
//===================================================

const InsertSortInputStream = (InArr, S) => {
  const lenInArr = InArr.length | 0;
  var StempArr = S.concat();

  for (let i = 0; i < lenInArr; i++) {
    StempArr = InsertSortInputData(InArr[i], StempArr);
  }

  return StempArr;
};

const SA1 = [-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5];
//const SA = [];
const newData = [-7, 6, 8, 3, -3, 0, 70, -12, 2, 1, 5];

var t0 = performance.now();

let resSortedArr = InsertSortInputStream(newData, SA1);

var t1 = performance.now();

console.log("InsertSortInputStream res", resSortedArr);
console.log(
  "Call to InsertSortInputStream took " + (t1 - t0) + " milliseconds."
);

// Tests and desired results
/*
[-4, -1, 0, 0, 3, 3, 3, 4, 4, 5, 5]
[-12, -7, -4, -3, -1, 0, 0, 0, 1, 2, 3, 3, 3, 3, 4, 4, 5, 5, 5, 6, 8, 70]
*/

/*
Write a function solution that, given an integer N, 
returns the maximum possible value obtained by inserting one '5'
digit inside the decimal representation of integer N.
Examples: 
1. Given N 268, the function should return 5268. 
2. Given N 670, the function should return 6750. 
3. Given N 0, the function should return 50. 
4. Given N -999, the function should return -5999. 
Assume that: N is an integer within the range [-8,000.8,000]
*/

const FindMaxWhenAddedDigit = (N, inDigit) => {
  const INSERT_ONLY = 0;
  let foundFirstIdx = 0;

  let digits = [];

  digits = ("" + Math.abs(N)).split("");

  // for positive nums find the 1st index of the smalest and insert at that index
  if (N >= 0) {
    console.log("start POS digits ", digits);

    foundFirstIdx = digits.findIndex(d => d <= "" + inDigit);
    console.log(`smalest than  inDigit  ${foundFirstIdx} `);
  }

  // for negative nums find the biggest and insert before
  else {
    console.log("start NEG digits ", digits);

    foundFirstIdx = digits.findIndex(d => d > "" + inDigit);

    console.log(digits);
    console.log(`+digits[1]  ${+digits[1]} `);
  }

  if (foundFirstIdx < 0) {
    digits.push(inDigit);
  } else {
    digits.splice(foundFirstIdx, INSERT_ONLY, "" + inDigit);
  }

  digits = (N < 0 ? -1 : 1) * Number(digits.join(""));

  return digits;
};

var res = 0;
// res = FindMaxWhenAddedDigit(2, 5);
// res = FindMaxWhenAddedDigit(0, 5);
// res = FindMaxWhenAddedDigit(6, 5);

//  res = FindMaxWhenAddedDigit(12, 5);
//  res = FindMaxWhenAddedDigit(52, 5);
//  res = FindMaxWhenAddedDigit(58, 5);
//  res = FindMaxWhenAddedDigit(98, 5);

// res = FindMaxWhenAddedDigit(128, 5);
// res = FindMaxWhenAddedDigit(528, 5);
// res = FindMaxWhenAddedDigit(158, 5);
// res = FindMaxWhenAddedDigit(918, 5);

//  res = FindMaxWhenAddedDigit(554, 5);
//  res = FindMaxWhenAddedDigit(814, 5);
// res = FindMaxWhenAddedDigit(268, 5);
//  res = FindMaxWhenAddedDigit(8000, 5);
// res = FindMaxWhenAddedDigit(111, 5);

// res = FindMaxWhenAddedDigit(-2, 5);
// res = FindMaxWhenAddedDigit(0, 5);
// res = FindMaxWhenAddedDigit(-6, 5);

// res = FindMaxWhenAddedDigit(-128, 5);
// res = FindMaxWhenAddedDigit(-528, 5);
// res = FindMaxWhenAddedDigit(-158, 5);
// res = FindMaxWhenAddedDigit(-918, 5);
// res = FindMaxWhenAddedDigit(-381, 5);

//  res = FindMaxWhenAddedDigit(-111, 5);
// res = FindMaxWhenAddedDigit(-125, 5);
// res = FindMaxWhenAddedDigit(-8000, 5);
//  res = FindMaxWhenAddedDigit(-999, 5);
// res = FindMaxWhenAddedDigit(-153, 5);

console.log(`sres  ${res} `);

//=================================